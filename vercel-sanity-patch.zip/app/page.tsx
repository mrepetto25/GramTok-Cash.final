export default function Page() {
  return (
    <main className="min-h-screen flex items-center justify-center p-8">
      <div className="max-w-xl w-full text-center">
        <h1 className="text-3xl font-semibold mb-2">Gramtok Cash</h1>
        <p className="opacity-80">Sanity Patch activo. Si ves esto, el deploy funcionó.</p>
      </div>
    </main>
  )
}
