# Gramtok Cash — Rescue Bundle

Este paquete agrega/normaliza los archivos mínimos para que Next.js compile y Vercel deje de tirar 404.

## Qué incluye
- `app/page.tsx` y `app/layout.tsx` (con `import './globals.css'`)
- `app/globals.css` (Tailwind base)
- `app/api/health/route.ts` (endpoint de salud)
- `next.config.mjs` (JS válido, sin TypeScript)
- `.env.example` (variables para Vercel)

## Cómo aplicarlo (GitHub UI)
1) En tu repo → **Add file → Upload files**.
2) Arrastrá el contenido de este ZIP a la **raíz** del repo (no a una subcarpeta).
3) Confirmá el **Commit** a `main`.

> Si tu código real está dentro de una subcarpeta, en Vercel → Settings → General → **Root Directory** poné el nombre de esa subcarpeta y guardá.

## Redeploy
- En Vercel → **Deployments → Redeploy → Clear build cache**.

## Smoke test
- `/<- home` debe renderizar.
- `/api/health` → `{ ok: true }`.
- `/api/auth` → `{ ok: true, message: "Auth endpoint alive" }` (si existe ese endpoint).
