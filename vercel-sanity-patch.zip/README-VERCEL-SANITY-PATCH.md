# Vercel Sanity Patch — Instrucciones rápidas

Este parche asegura que el build de Next.js funcione en Vercel eliminando conflictos de `next.config.mjs`.

## Qué hace
- **Reemplaza** `next.config.mjs` por `next.config.js` (CommonJS, 100% compatible).
- Asegura que exista `app/` con `page.tsx`, `layout.tsx` y `globals.css` (mínimos).

## Cómo aplicarlo (sin consola)
1) En tu repo de GitHub:
   - Si existe `next.config.mjs`, **borrá ese archivo** (Delete this file).
   - **Add file → Upload files** y subí:
     - `next.config.js`
     - La carpeta `app/` completa (si te falta).
2) Confirmá el **Commit** a `main`.
3) En Vercel → **Deployments** → **Redeploy** con **Clear build cache**.
4) Probá `/<home>` y `/api/health` (si lo tenés).

> Nota: si tu código está en una subcarpeta, en Vercel → Settings → General → Root Directory poné el nombre de esa subcarpeta.
