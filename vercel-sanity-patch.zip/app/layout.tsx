import './globals.css'

export const metadata = {
  title: 'Gramtok Cash',
  description: 'Marketplace de influencers y marcas — performance-based',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen">{children}</body>
    </html>
  )
}
